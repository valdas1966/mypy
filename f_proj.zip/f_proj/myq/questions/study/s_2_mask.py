from f_proj.myq.questions.i_2_mask import QuestionMask


q = QuestionMask(text='Question', answer='(Answer)')

print(q)