from f_proj.myq.generators.exam import GenExam


exam = GenExam.english.phrases(cnt=10)
