from f_proj.myq.generators.inner.exam.english import English
from f_proj.myq.generators.inner.exam.cs import CS


class GenExam:
    """
    ============================================================================
     Class for Exam-Generators.
    ============================================================================
    """

    english = English
    cs = CS
