from f_proj.myq.questions.i_1_text import QuestionText


class ManagerQuestionGui:

    def __init__(self) -> None:
        pass

    def run(self, question: QuestionText) -> None:
        pass