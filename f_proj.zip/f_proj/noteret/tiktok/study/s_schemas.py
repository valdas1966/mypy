from f_proj.noteret.tiktok.schemas import Schemas


Schemas.followers().display()
