from setuptools import setup, find_packages

setup(
    name='MyPy',
    version='0.1',
    packages=find_packages(),
    description='MyPy',
    author='VALDAS',
    author_email='valdas@gmail.com',
    url='https://github.com/valdas1966/mypy',
    install_requires=[
        # Any dependencies your project needs, e.g., 'requests>=2.25.1'
    ]
)
