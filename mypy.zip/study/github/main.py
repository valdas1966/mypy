
print('Hello Study')
