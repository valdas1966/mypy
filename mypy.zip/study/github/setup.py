from setuptools import setup, find_packages

setup(
    name='study',
    version='0.1',
    packages=find_packages(),
    description='Study',
    author='VALDAS',
    author_email='valdas@gmail.com',
    url='https://github.com/valdas1966/study',
    install_requires=
    [
        'setuptools>=67.6.0'
    ]
)
