import os


print(os.environ.get('VALDAS'))