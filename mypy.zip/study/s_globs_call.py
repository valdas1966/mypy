import s_globs
import s_globs_assign

print(s_globs.x)