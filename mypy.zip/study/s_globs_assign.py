import s_globs

s_globs.x = 8
