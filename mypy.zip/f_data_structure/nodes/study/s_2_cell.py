from f_data_structure.f_grid.cell import Cell
from f_data_structure.nodes.i_2_cell import NodeCell


cell_a = Cell()
node_a = NodeCell(name='A', cell=cell_a)
print(cell_a, node_a)
