from f_data_structure.collections.i_2_queue_fifo import QueueFIFO


q = QueueFIFO()
q.push(1)
print(q)