class TesterPy:
	def tester_1(self):		pass
	def tester_2(self):		pass