from f_utils import u_input


print(u_input.get('>'))

print(u_input.get(prompt='>', with_dt=True))
