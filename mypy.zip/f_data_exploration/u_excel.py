from f_data_exploration.table import Table
from f_excel.old_c_excel import Excel




def to_excel(table, xlsx):
    excel = Excel(xlsx)
