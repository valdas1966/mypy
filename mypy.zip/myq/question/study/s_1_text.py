from myq.question.i_1_text import QuestionText


q = QuestionText(text='2+2', answer='4')
q.get_input()
print(q.input)
