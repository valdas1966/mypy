class Groups:

    def __init__(self):
        self._d = dict()
        self._key = None

    def add(self, key, val):
        if key in self._d:







g = Groups()
g.init('a')
g.fill()
