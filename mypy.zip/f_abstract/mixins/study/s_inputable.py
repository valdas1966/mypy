from f_abstract.mixins.inputable import Inputable


i = Inputable()
i.get_input()
print(i.dt_prompt, i.input, i.dt_input)
