from f_excel.inner.wb.i_1_open_save_close import MyWorkBookOpenSaveClose


class MyWorkBook(MyWorkBookOpenSaveClose):
    pass
