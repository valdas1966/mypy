from f_excel.inner.ws.i_1_init import MyWorkSheetInit


class MyWorkSheet(MyWorkSheetInit):
    pass
