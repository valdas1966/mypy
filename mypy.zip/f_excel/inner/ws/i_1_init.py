
class MyWorkSheetInit:
    """
    ============================================================================
     Description: Excel-WorkSheet Init by openpyxl.worksheet
    ============================================================================
    """

    def __init__(self):
        # openpyxl.worksheet : The working WorkSheet
        self._ws = None
