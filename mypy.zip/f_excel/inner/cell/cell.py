from f_excel.inner.cell.i3_value import MyCellValue


class Cell(MyCellValue):
    pass
