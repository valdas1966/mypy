from f_file import txt


def test_write_lines():
    path = 'test.txt'
    txt.read.to_str(path)




