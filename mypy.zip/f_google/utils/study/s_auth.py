from f_google.utils import u_auth


path = 'd:\\temp\\2023\\12\\gsheet.json'
creds = u_auth.get_credentials(path_json=path)

