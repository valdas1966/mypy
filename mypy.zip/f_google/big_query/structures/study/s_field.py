from f_google.big_query.structures.field import Field


field = Field(name='a', dt='b')

print(field.name, field.dt)
