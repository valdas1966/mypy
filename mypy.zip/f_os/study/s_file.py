from f_os import u_file


print(u_file.to_drive(path_file=__file__))